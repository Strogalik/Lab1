# AnonimXChat
Anonim Chat Telegram

# Installtion
Install:
```
pip install aiogram emoji
```
:)
