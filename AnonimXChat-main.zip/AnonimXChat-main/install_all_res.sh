pip install aiogram emoji
